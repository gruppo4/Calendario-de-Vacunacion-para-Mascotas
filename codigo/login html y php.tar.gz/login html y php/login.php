<?php

$dbhost = "localhost";
$usuario = "id19659065_root";
$psw = "*dRZK0a70*H>}i=L";
$nombreBADA = "id19659065_red_social";
$nombre = $_POST['NombreU'];
$contra = $_POST['contra'];

$conn = mysqli_connect($dbhost, $usuario, $psw, $nombreBADA);


$resultado = mysqli_query($conn,"SELECT * FROM sesion WHERE nombre = '$nombre' AND contra = '$contra';");

$filas = mysqli_num_rows($resultado);

if ($filas > 0){
header('Location: https://calendario-de-mascotas.000webhostapp.com/calculadora.html');
} else {
header ('Location: https://calendario-de-mascotas.000webhostapp.com/register.html');
}

mysqli_free_result($resultado);
mysqli_close($conn);

?>