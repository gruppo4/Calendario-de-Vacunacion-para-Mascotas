<?php
	$dbhost="localhost";
	$user="id19615291_grupo4";
	$psw="Vacunacion4_";
	$nombd="id19615291_calendario";
	$nombre=$post["nombre"];
	$contra=$post["contra"];
	
	$conexion=mysqli_connect("localhost", "id19615291_grupo4", "Vacunacion4_", "id19615291_calendario");
	
	if(!$conexion){
		echo"no conexion";
	}
	else{
		echo"conexion establecida";
	}

	$consulta="select * From dueño";
	$result=mysqli_query($conexion,$consulta);

	if($result){
		echo"logueo";
	}
	else{
		echo"no logueo";
	}
?>
<?php

$dbhost = "localhost";
$usuario = "id19659065_root";
$psw = "*dRZK0a70*H>}i=L";
$nombreBADA = "id19659065_red_social";
$nombre = $_POST['NombreU'];
$contra = $_POST['contra'];

$conn = mysqli_connect($dbhost, $nombre, $psw, $nombreBADA);


$resultado = mysqli_query($conn,"SELECT * FROM dueño WHERE nombre = '$nombre' AND contra = '$contra';");

$filas = mysqli_num_rows($resultado);

if ($filas > 0){
header('Location: https://calendario-de-mascotas.000webhostapp.com/calculadora.html');
} else {
header ('Location: https://calendario-de-mascotas.000webhostapp.com/register.html');
}

mysqli_free_result($resultado);
mysqli_close($conn);

?>
	
