<?php
  $nombre = $_POST['nombre'];
  $psw = $_POST['psw'];

  $enlace = mysqli_connect($direccion,$usuario, $psw, $nombreBd)
  $consulta = "SELECT * FROM alumnos"
  $resultado = mysqli_query($enlace, $consulta)
 ?>
