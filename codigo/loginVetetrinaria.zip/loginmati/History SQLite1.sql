--- 09-08-2022 21:22:27
--- SQLite
create table alumnos(nombre VARCHAR (25) NOT NULL,
psw VARCHAR (25) NOT NULL);

--- 09-08-2022 21:23:02
--- SQLite
INSERT INTO alumnos(nombre,psw)VALUES(
'Franco','1234');

--- 09-08-2022 21:23:20
--- SQLite
INSERT INTO alumnos(nombre,psw)VALUES(
'Aylen','5678');

--- 09-08-2022 21:23:42
--- SQLite
INSERT INTO alumnos(nombre,psw)VALUES(
'Nazareno','9101');

--- 09-08-2022 21:23:54
--- SQLite
INSERT INTO alumnos(nombre,psw)VALUES(
'Diego','1121');



