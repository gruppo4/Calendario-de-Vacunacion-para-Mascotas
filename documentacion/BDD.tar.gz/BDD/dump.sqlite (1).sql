-- TABLE
CREATE TABLE Mascota (
Id_Mascota INT NOT NULL,
Nombre varchar (50) NOT NULL,
Tipo VARCHAR (50) NOT NULL, 
Raza varchar (50) NOT NULL,
DNI int not NULL,
PRIMARY KEY (Id_Mascota),
FOREIGN kEy (DNI) REFERENCES Usuario(DNI));
CREATE TABLE Usuario (
DNI INT NOT NULL,
Nombre varchar (50) NOT NULL,
Direccion VARCHAR (50) NOT NULL, 
Email varchar (50) NOT NULL,
Contraseña VARCHAR (50) not NULL,
Id_Mascota int not NULL,
PRIMARY KEY (DNI),
FOREIGN kEy (Id_Mascota) REFERENCES Mascota(Id_Mascota));
CREATE TABLE Veterinaria (
Fecha_vac date NOT NULL,
Tipo_vac varchar (50) NOT NULL,
Cant_vac INt NOT NULL, 
Nom_vet varchar (50) NOT NULL,
ID_vet int not NULL,
DNI int not NULL,
PRIMARY KEY (ID_vet),
FOREIGN kEy (DNI) REFERENCES usuario(DNI));
 
-- INDEX
 
-- TRIGGER
 
-- VIEW
 
